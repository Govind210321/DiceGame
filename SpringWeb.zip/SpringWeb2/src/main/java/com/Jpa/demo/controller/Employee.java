package com.Jpa.demo.controller;

import lombok.Data;

@Data
public class Employee {
 
private String uName;
private Integer sId; 
}
