package com.Jpa.demo.controller;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class User1 {
 
private Integer sid;
private String Sname;
private Integer sal;

}
