package com.Jpa.demo.controller;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UserController {
	@GetMapping("/call")
	public String register(Map<String, Object> model) {
		model.put("s1", "Govind");
		List<User1> u1 = List.of(new User1(1, "steve", 321), new User1(2, "roger", 421), new User1(3, "ellen", 521),
				new User1(6, "bucky", 621)

		);
		model.put("ellen", u1);
		
		return "UserRegister";
	}
}
