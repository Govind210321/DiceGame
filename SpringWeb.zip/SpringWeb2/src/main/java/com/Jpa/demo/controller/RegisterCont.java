package com.Jpa.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller

public class RegisterCont {
@GetMapping("/show")
	public String Register()
	{
	 return "UserRegistery";
	}
@PostMapping("/reg")
public String  Reg(@ModelAttribute Employee employee,Model model)
{
System.out.println(employee);	
model.addAttribute("goal",employee);
 return "Lean";
}
}
